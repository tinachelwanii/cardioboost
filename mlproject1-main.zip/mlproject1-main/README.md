# mlproject1

Study of classification and prediction of heart disease using ANN
