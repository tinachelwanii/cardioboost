from flask import Flask, render_template, request, redirect, url_for, session, flash
import pickle
import numpy as np
import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash





# Updated: All models use the same features now
model_features = {
    'mlp': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight'],
    'ada': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight'],
    'grad': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight']
}

# Dictionary for display names 
model_display_names = {
    'ada': 'AdaBoost',
    'grad': 'Gradient Boosting',
    'mlp': 'Neural Network (MLP)'
}

# Load all models at application startup
models = {}
for model_name in model_features.keys():
    model_path = f'{model_name}.pkl'
    if os.path.exists(model_path):
        try:
            with open(model_path, 'rb') as f:
                models[model_name] = pickle.load(f)
            print(f"Loaded model: {model_name}")
        except Exception as e:
            print(f"Error loading model {model_name}: {str(e)}")
    else:
        print(f"Warning: Model file {model_path} not found")

# Print the loaded models for debugging
print(f"Available models: {list(models.keys())}")

# Dictionary for form field to feature mapping
field_to_feature = {
    'a': 'age',         # Age
    'b': 'gender',      # Gender
    'c': 'height',      # Height
    'd': 'weight',      # Weight
    'e': 'ap_hi',       # Systolic BP
    'f': 'ap_lo',       # Diastolic BP
    'g': 'cholesterol', # Cholesterol
    'h': 'gluc',        # Glucose
    'i': 'smoke',       # Smoke
    'j': 'alco',        # Alcohol
    'k': 'active'       # Activity
}

# Updated risk thresholds based on clinical guidelines
risk_thresholds = {
    "age": 55,          # Increased risk above age 55
    "ap_hi": {
        "low": 90,         # Low below 90
        "normal": 120,     # Normal up to 120
        "elevated": 130,   # Elevated 121-129
        "high": 140        # High 130+
    },
    "ap_lo": {
        "low": 60,         # Low below 60
        "normal": 80,      # Normal up to 80
        "high": 90         # High 81+
    },
    "cholesterol": {
        "normal": 1,       # Normal
        "borderline": 2,   # Above normal
        "high": 3          # Well above normal
    },
    "gluc": {
        "normal": 1,       # Normal
        "pre_diabetic": 2, # Above normal
        "diabetic": 3      # Well above normal
    },
    "bmi": {
        "normal": 25,      # Normal below 25
        "overweight": 30,  # Overweight 25-30
        "obese": 35        # Obese 30+
    },
    "active": 0,         # Inactive is risk factor
    "smoke": 1           # Smoker is risk factor
}

# Display names for features
feature_display_names = {
    "age": "Age",
    "height": "Height",
    "weight": "Weight",
    "ap_hi": "Systolic Blood Pressure",
    "ap_lo": "Diastolic Blood Pressure",
    "cholesterol": "Cholesterol",
    "gluc": "Blood Glucose",
    "active": "Physical Activity",
    "smoke": "Smoking Status",
    "alco": "Alcohol Consumption",
    "gender": "Gender"
}

# Initialize the database
def init_db():
    conn = sqlite3.connect('heart_disease_prediction.db')
    cursor = conn.cursor()
    
    # Create users table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully")

# Initialize the database when the app starts
init_db()

# Add this function at the start of your app.py, right after the init_db function

def init_prediction_table():
    conn = sqlite3.connect('heart_disease_prediction.db')
    cursor = conn.cursor()
    
    # Create prediction_history table if it doesn't exist
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS prediction_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        prediction INTEGER NOT NULL,
        risk_level TEXT NOT NULL,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        age REAL,
        gender INTEGER,
        height REAL,
        weight REAL,
        ap_hi REAL,
        ap_lo REAL,
        cholesterol INTEGER,
        gluc INTEGER,
        smoke INTEGER,
        alco INTEGER,
        active INTEGER,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    """)
    
    conn.commit()
    conn.close()
    print("Prediction history table initialized successfully")

# Call this function right after init_db()
# Add this after the line: init_db()
init_prediction_table()

# Function to calculate risk score based on user data
def calculate_risk_score(user_data):
    score = 0
    
    # Age risk
    if user_data['age'] > risk_thresholds['age']:
        score += 2
    
    # Blood pressure (systolic)
    if user_data['ap_hi'] < risk_thresholds['ap_hi']['low']:
        score += 1  # Low BP
    elif user_data['ap_hi'] <= risk_thresholds['ap_hi']['normal']:
        score += 0  # Normal
    elif user_data['ap_hi'] < risk_thresholds['ap_hi']['elevated']:
        score += 1  # Elevated
    elif user_data['ap_hi'] < risk_thresholds['ap_hi']['high']:
        score += 2  # Stage 1 hypertension
    else:
        score += 3  # Stage 2 hypertension
    
    # Blood pressure (diastolic)
    if user_data['ap_lo'] < risk_thresholds['ap_lo']['low']:
        score += 1  # Low BP
    elif user_data['ap_lo'] <= risk_thresholds['ap_lo']['normal']:
        score += 0  # Normal
    elif user_data['ap_lo'] < risk_thresholds['ap_lo']['high']:
        score += 1  # Stage 1 hypertension
    else:
        score += 2  # Stage 2 hypertension
    
    # Cholesterol
    if user_data['cholesterol'] == risk_thresholds['cholesterol']['normal']:
        score += 0  # Normal
    elif user_data['cholesterol'] == risk_thresholds['cholesterol']['borderline']:
        score += 1  # Above normal
    else:
        score += 2  # Well above normal
    
    # Blood glucose
    if user_data['gluc'] == risk_thresholds['gluc']['normal']:
        score += 0  # Normal
    elif user_data['gluc'] == risk_thresholds['gluc']['pre_diabetic']:
        score += 1  # Above normal
    else:
        score += 2  # Well above normal
    
    # Smoking status
    if user_data['smoke'] == risk_thresholds['smoke']:
        score += 2
    
    # Physical activity (inactive = higher risk)
    if user_data['active'] == risk_thresholds['active']:
        score += 1
    
    # BMI
    height_m = user_data['height'] / 100  # Convert cm to m
    bmi = user_data['weight'] / (height_m ** 2)
    
    if bmi < risk_thresholds['bmi']['normal']:
        score += 0  # Normal
    elif bmi < risk_thresholds['bmi']['overweight']:
        score += 1  # Overweight
    elif bmi < risk_thresholds['bmi']['obese']:
        score += 2  # Obese
    else:
        score += 3  # Severely obese
    
    return score

# Function to determine risk category based on score
def get_risk_category(score):
    if score <= 3:
        return "low"
    elif score <= 6:
        return "medium"
    else:
        return "high"

# Also add a function to save prediction results to the database:
def save_prediction(user_email, prediction_data, final_prediction, risk_level):
    try:
        # Connect to database
        conn = sqlite3.connect('heart_disease_prediction.db')
        cursor = conn.cursor()
        
        # Get user_id from email
        cursor.execute("SELECT id FROM users WHERE email = ?", (user_email,))
        user_row = cursor.fetchone()
        
        if not user_row:
            conn.close()
            return False
            
        user_id = user_row[0]
        
        # Insert prediction data
        cursor.execute("""
        INSERT INTO prediction_history 
        (user_id, prediction, risk_level, age, gender, height, weight, 
         ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id, 
            final_prediction,
            risk_level,
            prediction_data.get('age', 0),
            prediction_data.get('gender', 0),
            prediction_data.get('height', 0),
            prediction_data.get('weight', 0),
            prediction_data.get('ap_hi', 0),
            prediction_data.get('ap_lo', 0),
            prediction_data.get('cholesterol', 0),
            prediction_data.get('gluc', 0),
            prediction_data.get('smoke', 0),
            prediction_data.get('alco', 0),
            prediction_data.get('active', 0)
        ))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Error saving prediction: {str(e)}")
        return False

app = Flask(__name__)
# Configure Flask app to use sessions
app.secret_key = 'your_secret_key_here'  # Change this to a random string in production

@app.route('/')
def landing():
    # This will be your landing page that anyone can access without login
    return render_template('index.html')

@app.route('/home')
def home():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', session=session)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Connect to the database
        conn = sqlite3.connect('heart_disease_prediction.db')
        conn.row_factory = sqlite3.Row  # This enables column access by name
        cursor = conn.cursor()
        
        # Check if user exists
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            # Set session
            session['user_email'] = email
            session['user_name'] = user['name']
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password', 'error')
            return render_template('login.html')
    
    # GET request
    return render_template('login.html')

@app.route('/signup', methods=['POST'])
def signup():
    name = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    
    # Validate
    if not all([name, email, password, confirm_password]):
        flash('All fields are required', 'error')
        return render_template('login.html')
    
    if password != confirm_password:
        flash('Passwords do not match', 'error')
        return render_template('login.html')
    
    # Connect to the database
    conn = sqlite3.connect('heart_disease_prediction.db')
    cursor = conn.cursor()
    
    # Check if user already exists
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    existing_user = cursor.fetchone()
    
    if existing_user:
        conn.close()
        flash('Email already registered', 'error')
        return render_template('login.html')
    
    # Hash the password and store the user
    hashed_password = generate_password_hash(password)
    cursor.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", 
                   (name, email, hashed_password))
    conn.commit()
    conn.close()
    
    flash('Account created successfully! Please log in.', 'success')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_email', None)
    session.pop('user_name', None)
    return redirect(url_for('login'))

@app.route('/predict', methods=['POST'])
def predict():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    try:
        # Print the available models for debugging
        print(f"Using models: {list(models.keys())}")
        
        # Check if all fields are submitted
        required_fields = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']
        
        for field in required_fields:
            if not request.form.get(field) or request.form.get(field).strip() == '':
                return render_template('error.html', message=f"Please fill in all fields. Missing: {field}")
        
        # Convert form data to float values
        user_data = {}
        try:
            for field, value in request.form.items():
                if field in field_to_feature:
                    feature_name = field_to_feature[field]
                    user_data[feature_name] = float(value)
        except ValueError as e:
            return render_template('error.html', message=f"Please enter valid numeric values: {str(e)}")
        
        # Get predictions from all models
        model_predictions = []
        overall_risk_probability = 0
        positive_predictions = 0
        
        # Ensure all three models are processed
        if len(models) < 3:
            print(f"Warning: Not all models are loaded. Available models: {list(models.keys())}")
        
        for model_name, model_obj in models.items():
            # Get features for this model
            model_features_list = model_features[model_name]
            
            # Extract only the features this model uses
            model_input = []
            for feature in model_features_list:
                if feature not in user_data:
                    print(f"Warning: Feature {feature} not found in user data for model {model_name}")
                    # Use a default value
                    model_input.append(0)
                else:
                    model_input.append(user_data[feature])
            
            model_arr = np.array([model_input], dtype=np.float64)
            
            try:
                # Make prediction
                prediction = model_obj.predict(model_arr)[0]
                
                # Try to get probability
                try:
                    probability = model_obj.predict_proba(model_arr)[0][1]
                except:
                    # Some models might not support predict_proba
                    probability = 0.8 if prediction == 1 else 0.2
                
                # Add to overall calculations
                if prediction == 1:
                    positive_predictions += 1
                overall_risk_probability += probability
                
                # Store the results
                model_predictions.append({
                    'name': model_display_names[model_name],
                    'prediction': int(prediction),
                    'probability': round(probability * 100, 1)
                })
                
                print(f"Model {model_name} prediction: {prediction}, probability: {probability}")
            except Exception as e:
                print(f"Error making prediction with model {model_name}: {str(e)}")
                # Add a placeholder with error
                model_predictions.append({
                    'name': f"{model_display_names[model_name]} (Error)",
                    'prediction': 0,
                    'probability': 0,
                    'error': str(e)
                })
        
        # Debug the predictions
        print(f"All model predictions: {model_predictions}")
        
        # Calculate average probability
        if len(model_predictions) > 0:
            avg_probability = overall_risk_probability / len(model_predictions) * 100
            # Calculate consensus percentage
            consensus_percentage = (positive_predictions / len(model_predictions)) * 100
        else:
            avg_probability = 0
            consensus_percentage = 0
        
        # Calculate risk score based on clinical factors
        risk_score = calculate_risk_score(user_data)
        
        # Determine risk level based on score
        risk_level = get_risk_category(risk_score)
            
        # Calculate BMI for risk factor analysis
        height_m = user_data["height"] / 100  # Convert cm to m
        bmi = user_data["weight"] / (height_m ** 2)
        
        # Identify influential factors for personalized recommendations
        risk_factors = []
        health_considerations = []
        
        # Check for low blood pressure (systolic)
        if user_data["ap_hi"] < risk_thresholds["ap_hi"]["low"]:
            health_considerations.append({
                "factor": "Systolic Blood Pressure", 
                "value": f"{int(user_data['ap_hi'])} mmHg (low)",
                "message": "Low systolic blood pressure may indicate other health issues and should be discussed with your doctor"
            })
        
        # Check for low blood pressure (diastolic)
        if user_data["ap_lo"] < risk_thresholds["ap_lo"]["low"]:
            health_considerations.append({
                "factor": "Diastolic Blood Pressure", 
                "value": f"{int(user_data['ap_lo'])} mmHg (low)",
                "message": "Low diastolic blood pressure may indicate other health issues and should be discussed with your doctor"
            })
        
        # Check for high blood pressure (systolic)
        if user_data["ap_hi"] > risk_thresholds["ap_hi"]["normal"]:
            bp_status = "elevated"
            if user_data["ap_hi"] >= risk_thresholds["ap_hi"]["elevated"]:
                bp_status = "stage 1 hypertension"
            if user_data["ap_hi"] >= risk_thresholds["ap_hi"]["high"]:
                bp_status = "stage 2 hypertension"
                
            risk_factors.append({
                "factor": "Systolic Blood Pressure", 
                "value": f"{int(user_data['ap_hi'])} mmHg ({bp_status})",
                "message": f"{bp_status.capitalize()} increases heart disease risk"
            })
        
        # Check for high blood pressure (diastolic)
        if user_data["ap_lo"] > risk_thresholds["ap_lo"]["normal"]:
            bp_status = "stage 1 hypertension"
            if user_data["ap_lo"] >= risk_thresholds["ap_lo"]["high"]:
                bp_status = "stage 2 hypertension"
                
            risk_factors.append({
                "factor": "Diastolic Blood Pressure", 
                "value": f"{int(user_data['ap_lo'])} mmHg ({bp_status})", 
                "message": f"{bp_status.capitalize()} increases heart disease risk"
            })
        
        # Check for high cholesterol
        if user_data["cholesterol"] > risk_thresholds["cholesterol"]["normal"]:
            chol_status = "above normal" if user_data["cholesterol"] == 2 else "high"
            risk_factors.append({
                "factor": "Cholesterol", 
                "value": chol_status,
                "message": f"{chol_status.capitalize()} cholesterol is a major risk factor for heart disease"
            })
        
        # Check for high glucose
        if user_data["gluc"] > risk_thresholds["gluc"]["normal"]:
            gluc_status = "pre-diabetic" if user_data["gluc"] == 2 else "diabetic"
            risk_factors.append({
                "factor": "Blood Glucose", 
                "value": gluc_status,
                "message": f"{gluc_status.capitalize()} glucose levels increase heart disease risk"
            })
        
        # Check for age risk
        if user_data["age"] > risk_thresholds["age"]:
            risk_factors.append({
                "factor": "Age", 
                "value": f"{int(user_data['age'])} years",
                "message": "Age over 55 increases heart disease risk"
            })
        
        # Check for physical inactivity
        if user_data["active"] == risk_thresholds["active"]:
            risk_factors.append({
                "factor": "Physical Activity", 
                "value": "Inactive",
                "message": "Physical inactivity is a major risk factor for heart disease"
            })
            
        # Check for smoking
        if user_data["smoke"] == risk_thresholds["smoke"]:
            risk_factors.append({
                "factor": "Smoking", 
                "value": "Smoker",
                "message": "Smoking significantly increases heart disease risk"
            })
        
        # Check BMI
        if bmi >= risk_thresholds["bmi"]["normal"]:
            bmi_status = "overweight"
            if bmi >= risk_thresholds["bmi"]["overweight"]:
                bmi_status = "obese"
            if bmi >= risk_thresholds["bmi"]["obese"]:
                bmi_status = "severely obese"
                
            risk_factors.append({
                "factor": "BMI", 
                "value": f"{bmi:.1f} ({bmi_status})",
                "message": f"BMI indicates {bmi_status}, which increases heart disease risk"
            })
        
        # Sort risk factors by importance
        sorted_risk_factors = sorted(risk_factors, key=lambda x: {
            "Cholesterol": 1,
            "Blood Glucose": 2,
            "Systolic Blood Pressure": 3,
            "Diastolic Blood Pressure": 4,
            "Smoking": 5,
            "BMI": 6,
            "Age": 7,
            "Physical Activity": 8
        }.get(x["factor"], 99))
        
        # Determine final prediction based on majority
        final_prediction = 1 if positive_predictions >= len(model_predictions)/2 else 0
        
        # Save prediction to database
        save_prediction(session.get('user_email'), user_data, final_prediction, risk_level)
        
        return render_template('result.html', 
                              final_prediction=final_prediction,
                              model_predictions=model_predictions,
                              risk_level=risk_level,
                              risk_score=risk_score,
                              risk_factors=sorted_risk_factors,
                              health_considerations=health_considerations,
                              session=session)
    
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return render_template('error.html', message=f"An error occurred: {str(e)}")

@app.route('/history')
def history():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    try:
        # Get user email from session
        user_email = session.get('user_email')
        
        # Connect to database
        conn = sqlite3.connect('heart_disease_prediction.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # First, get the user_id from the email
        cursor.execute("SELECT id FROM users WHERE email = ?", (user_email,))
        user_row = cursor.fetchone()
        
        if not user_row:
            flash('User not found', 'error')
            return redirect(url_for('login'))
            
        user_id = user_row['id']
        
        # Now get user's prediction history
        cursor.execute("""
        SELECT id, prediction, risk_level, date, 
               age, gender, height, weight, ap_hi, ap_lo, 
               cholesterol, gluc, smoke, alco, active
        FROM prediction_history
        WHERE user_id = ?
        ORDER BY date DESC
        """, (user_id,))
        
        history_data = cursor.fetchall()
        
        # Process data for display
        predictions = []
        for record in history_data:
            # Convert numeric cholesterol to text for display
            chol_text = "Normal"
            if record['cholesterol'] == 2:
                chol_text = "Above Normal"
            elif record['cholesterol'] == 3:
                chol_text = "High"
                
            predictions.append({
                'id': record['id'],
                'prediction': record['prediction'],
                'risk_level': record['risk_level'],
                'date': record['date'],
                'age': int(record['age']),
                'systolic': int(record['ap_hi']),
                'diastolic': int(record['ap_lo']),
                'cholesterol': chol_text
            })
        
        conn.close()
        return render_template('history.html', predictions=predictions, session=session)
        
    except Exception as e:
        import traceback
        print("Full traceback:")
        traceback.print_exc()
        return render_template('error.html', message=f"An error occurred loading history: {str(e)}")


        
if __name__ == "__main__":
    app.run(debug=True)