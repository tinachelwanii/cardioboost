from flask import Flask, render_template, request, redirect, url_for, session, flash
import pickle
import numpy as np
import os
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

# Updated: All models use the same features now
model_features = {
    'mlp': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight'],
    'ada': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight'],
    'grad': ['ap_hi', 'ap_lo', 'cholesterol', 'smoke', 'weight']
}

# Dictionary for display names 
model_display_names = {
    'ada': 'AdaBoost',
    'grad': 'Gradient Boosting',
    'mlp': 'Neural Network (MLP)'
}

# Load all models at application startup
models = {}
for model_name in model_features.keys():
    model_path = f'{model_name}.pkl'
    if os.path.exists(model_path):
        try:
            with open(model_path, 'rb') as f:
                models[model_name] = pickle.load(f)
            print(f"Loaded model: {model_name}")
        except Exception as e:
            print(f"Error loading model {model_name}: {str(e)}")
    else:
        print(f"Warning: Model file {model_path} not found")

# Print the loaded models for debugging
print(f"Available models: {list(models.keys())}")

# Dictionary for form field to feature mapping
field_to_feature = {
    'a': 'age',         # Age
    'b': 'gender',      # Gender
    'c': 'height',      # Height
    'd': 'weight',      # Weight
    'e': 'ap_hi',       # Systolic BP
    'f': 'ap_lo',       # Diastolic BP
    'g': 'cholesterol', # Cholesterol
    'h': 'gluc',        # Glucose
    'i': 'smoke',       # Smoke
    'j': 'alco',        # Alcohol
    'k': 'active'       # Activity
}

# Risk thresholds for identifying influential factors
risk_thresholds = {
    "age": 50,          # Age above 50
    "ap_hi": 130,       # Above 130
    "ap_lo": 80,        # Above 80
    "cholesterol": 1,   # Above normal (2 or 3)
    "gluc": 1,          # Above normal (2 or 3)
    "active": 1,        # Inactive (0)
    "smoke": 0          # Smoker (1)
}

# Display names for features
feature_display_names = {
    "age": "Age",
    "height": "Height",
    "weight": "Weight",
    "ap_hi": "Systolic Blood Pressure",
    "ap_lo": "Diastolic Blood Pressure",
    "cholesterol": "Cholesterol",
    "gluc": "Blood Glucose",
    "active": "Physical Activity",
    "smoke": "Smoking Status",
    "alco": "Alcohol Consumption",
    "gender": "Gender"
}

# Initialize the database
def init_db():
    conn = sqlite3.connect('heart_disease_prediction.db')
    cursor = conn.cursor()
    
    # Create users table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')
    
    # Create predictions history table
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS prediction_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        prediction INTEGER NOT NULL,
        risk_level TEXT,
        date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        age REAL,
        gender REAL,
        height REAL,
        weight REAL,
        ap_hi REAL,
        ap_lo REAL,
        cholesterol REAL,
        gluc REAL,
        smoke REAL,
        alco REAL,
        active REAL,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')
    
    conn.commit()
    conn.close()
    print("Database initialized successfully")

# Initialize the database when the app starts
init_db()

app = Flask(__name__)
# Configure Flask app to use sessions
app.secret_key = 'your_secret_key_here'  # Change this to a random string in production

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Connect to the database
        conn = sqlite3.connect('heart_disease_prediction.db')
        conn.row_factory = sqlite3.Row  # This enables column access by name
        cursor = conn.cursor()
        
        # Check if user exists
        cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            # Set session
            session['user_email'] = email
            session['user_name'] = user['name']
            session['user_id'] = user['id']
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid email or password', 'error')
            return render_template('login.html')
    
    # GET request
    return render_template('login.html')

@app.route('/signup', methods=['POST'])
def signup():
    name = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    
    # Validate
    if not all([name, email, password, confirm_password]):
        flash('All fields are required', 'error')
        return render_template('login.html')
    
    if password != confirm_password:
        flash('Passwords do not match', 'error')
        return render_template('login.html')
    
    # Connect to the database
    conn = sqlite3.connect('heart_disease_prediction.db')
    cursor = conn.cursor()
    
    # Check if user already exists
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    existing_user = cursor.fetchone()
    
    if existing_user:
        conn.close()
        flash('Email already registered', 'error')
        return render_template('login.html')
    
    # Hash the password and store the user
    hashed_password = generate_password_hash(password)
    cursor.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", 
                   (name, email, hashed_password))
    conn.commit()
    conn.close()
    
    flash('Account created successfully! Please log in.', 'success')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_email', None)
    session.pop('user_name', None)
    session.pop('user_id', None)
    return redirect(url_for('login'))

@app.route('/')
def home():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    return render_template('home.html', session=session)

@app.route('/predict', methods=['POST'])
def predict():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    try:
        # Print the available models for debugging
        print(f"Using models: {list(models.keys())}")
        
        # Check if all fields are submitted
        required_fields = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k']
        
        for field in required_fields:
            if not request.form.get(field) or request.form.get(field).strip() == '':
                return render_template('error.html', message=f"Please fill in all fields. Missing: {field}")
        
        # Convert form data to float values
        user_data = {}
        try:
            for field, value in request.form.items():
                if field in field_to_feature:
                    feature_name = field_to_feature[field]
                    user_data[feature_name] = float(value)
        except ValueError as e:
            return render_template('error.html', message=f"Please enter valid numeric values: {str(e)}")
        
        # Get predictions from all models
        model_predictions = []
        overall_risk_probability = 0
        positive_predictions = 0
        
        # Ensure all three models are processed
        if len(models) < 3:
            print(f"Warning: Not all models are loaded. Available models: {list(models.keys())}")
        
        for model_name, model_obj in models.items():
            # Get features for this model
            model_features_list = model_features[model_name]
            
            # Extract only the features this model uses
            model_input = []
            for feature in model_features_list:
                if feature not in user_data:
                    print(f"Warning: Feature {feature} not found in user data for model {model_name}")
                    # Use a default value
                    model_input.append(0)
                else:
                    model_input.append(user_data[feature])
            
            model_arr = np.array([model_input], dtype=np.float64)
            
            try:
                # Make prediction
                prediction = model_obj.predict(model_arr)[0]
                
                # Try to get probability
                try:
                    probability = model_obj.predict_proba(model_arr)[0][1]
                except:
                    # Some models might not support predict_proba
                    probability = 0.8 if prediction == 1 else 0.2
                
                # Add to overall calculations
                if prediction == 1:
                    positive_predictions += 1
                overall_risk_probability += probability
                
                # Store the results
                model_predictions.append({
                    'name': model_display_names[model_name],
                    'prediction': int(prediction),
                    'probability': round(probability * 100, 1)
                })
                
                print(f"Model {model_name} prediction: {prediction}, probability: {probability}")
            except Exception as e:
                print(f"Error making prediction with model {model_name}: {str(e)}")
                # Add a placeholder with error
                model_predictions.append({
                    'name': f"{model_display_names[model_name]} (Error)",
                    'prediction': 0,
                    'probability': 0,
                    'error': str(e)
                })
        
        # Debug the predictions
        print(f"All model predictions: {model_predictions}")
        
        # Calculate average probability and determine overall risk level
        if len(model_predictions) > 0:
            avg_probability = overall_risk_probability / len(model_predictions) * 100
            
            if avg_probability < 30:
                risk_level = "low"
            elif avg_probability < 70:
                risk_level = "medium"
            else:
                risk_level = "high"
            
            # Calculate consensus percentage
            consensus_percentage = (positive_predictions / len(model_predictions)) * 100
        else:
            avg_probability = 0
            risk_level = "unknown"
            consensus_percentage = 0
            
        # Calculate BMI for risk factor analysis
        height_m = user_data["height"] / 100  # Convert cm to m
        bmi = user_data["weight"] / (height_m ** 2)
        
        # Identify influential factors for personalized recommendations
        risk_factors = []
        
        # Check for high blood pressure
        if user_data["ap_hi"] >= risk_thresholds["ap_hi"]:
            risk_factors.append({
                "factor": "Systolic Blood Pressure", 
                "value": f"{int(user_data['ap_hi'])} mmHg",
                "message": "Elevated systolic blood pressure increases heart disease risk"
            })
        
        if user_data["ap_lo"] >= risk_thresholds["ap_lo"]:
            risk_factors.append({
                "factor": "Diastolic Blood Pressure", 
                "value": f"{int(user_data['ap_lo'])} mmHg", 
                "message": "Elevated diastolic blood pressure increases heart disease risk"
            })
        
        # Check for high cholesterol
        if user_data["cholesterol"] > risk_thresholds["cholesterol"]:
            chol_status = "above normal" if user_data["cholesterol"] == 2 else "high"
            risk_factors.append({
                "factor": "Cholesterol", 
                "value": chol_status,
                "message": f"{chol_status.capitalize()} cholesterol is a major risk factor for heart disease"
            })
        
        # Check for high glucose
        if user_data["gluc"] > risk_thresholds["gluc"]:
            gluc_status = "pre-diabetic" if user_data["gluc"] == 2 else "diabetic"
            risk_factors.append({
                "factor": "Blood Glucose", 
                "value": gluc_status,
                "message": f"{gluc_status.capitalize()} glucose levels increase heart disease risk"
            })
        
        # Check for age risk
        if user_data["age"] > risk_thresholds["age"]:
            risk_factors.append({
                "factor": "Age", 
                "value": f"{int(user_data['age'])} years",
                "message": "Age over 50 increases heart disease risk"
            })
        
        # Check for physical inactivity
        if user_data["active"] == 0:
            risk_factors.append({
                "factor": "Physical Activity", 
                "value": "Inactive",
                "message": "Physical inactivity is a major risk factor for heart disease"
            })
            
        # Check for smoking
        if user_data["smoke"] == 1:
            risk_factors.append({
                "factor": "Smoking", 
                "value": "Smoker",
                "message": "Smoking significantly increases heart disease risk"
            })
        
        # Check BMI
        if bmi >= 25:
            bmi_status = "overweight" if bmi < 30 else "obese"
            risk_factors.append({
                "factor": "BMI", 
                "value": f"{bmi:.1f} ({bmi_status})",
                "message": f"BMI indicates {bmi_status}, which increases heart disease risk"
            })
        
        # Sort risk factors by importance
        sorted_risk_factors = sorted(risk_factors, key=lambda x: {
            "Cholesterol": 1,
            "Blood Glucose": 2,
            "Systolic Blood Pressure": 3,
            "Diastolic Blood Pressure": 4,
            "Smoking": 5,
            "BMI": 6,
            "Age": 7,
            "Physical Activity": 8
        }.get(x["factor"], 99))
        
        # Determine final prediction based on majority
        final_prediction = 1 if positive_predictions >= len(model_predictions)/2 else 0
        
        # Save prediction to database
        try:
            conn = sqlite3.connect('heart_disease_prediction.db')
            cursor = conn.cursor()
            
            # Get user_id from session
            user_id = session.get('user_id')
            
            # Insert prediction record
            cursor.execute("""
            INSERT INTO prediction_history 
            (user_id, prediction, risk_level, age, gender, height, weight, 
             ap_hi, ap_lo, cholesterol, gluc, smoke, alco, active)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                user_id, 
                final_prediction, 
                risk_level,
                user_data.get('age'),
                user_data.get('gender'),
                user_data.get('height'),
                user_data.get('weight'),
                user_data.get('ap_hi'),
                user_data.get('ap_lo'),
                user_data.get('cholesterol'),
                user_data.get('gluc'),
                user_data.get('smoke'),
                user_data.get('alco'),
                user_data.get('active')
            ))
            
            conn.commit()
            conn.close()
            print("Prediction saved to database")
        except Exception as e:
            print(f"Error saving prediction to database: {str(e)}")
        
        return render_template('result.html', 
                              final_prediction=final_prediction,
                              model_predictions=model_predictions,
                              risk_level=risk_level,
                              risk_factors=sorted_risk_factors,
                              session=session)
    
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return render_template('error.html', message=f"An error occurred: {str(e)}")

@app.route('/history')
def history():
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    try:
        # Get user_id from session
        user_id = session.get('user_id')
        
        # Connect to database
        conn = sqlite3.connect('heart_disease_prediction.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get user's prediction history
        cursor.execute("""
        SELECT id, prediction, risk_level, date, 
               age, gender, height, weight, ap_hi, ap_lo, 
               cholesterol, gluc, smoke, alco, active
        FROM prediction_history
        WHERE user_id = ?
        ORDER BY date DESC
        """, (user_id,))
        
        history_data = cursor.fetchall()
        conn.close()
        
        # Process data for display
        predictions = []
        for record in history_data:
            # Calculate BMI
            height_m = record['height'] / 100
            bmi = record['weight'] / (height_m ** 2)
            
            # Process cholesterol and glucose values
            cholesterol_text = "Normal"
            if record['cholesterol'] == 2:
                cholesterol_text = "Above Normal"
            elif record['cholesterol'] == 3:
                cholesterol_text = "High"
                
            glucose_text = "Normal"
            if record['gluc'] == 2:
                glucose_text = "Above Normal"
            elif record['gluc'] == 3:
                glucose_text = "High"
            
            gender_text = "Male" if record['gender'] == 1 else "Female"
            
            predictions.append({
                'id': record['id'],
                'date': record['date'],
                'prediction': record['prediction'],
                'risk_level': record['risk_level'],
                'age': int(record['age']),
                'gender': gender_text,
                'height': int(record['height']),
                'weight': int(record['weight']),
                'bmi': round(bmi, 1),
                'systolic': int(record['ap_hi']),
                'diastolic': int(record['ap_lo']),
                'cholesterol': cholesterol_text,
                'glucose': glucose_text,
                'smoking': "Yes" if record['smoke'] == 1 else "No",
                'alcohol': "Heavy" if record['alco'] == 1 else "None/Moderate",
                'active': "Yes" if record['active'] == 1 else "No"
            })
        
        return render_template('history.html', predictions=predictions, session=session)
        
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return render_template('error.html', message=f"An error occurred loading history: {str(e)}")

@app.route('/history/<int:prediction_id>')
def view_prediction(prediction_id):
    if 'user_email' not in session:
        return redirect(url_for('login'))
    
    try:
        # Get user_id from session
        user_id = session.get('user_id')
        
        # Connect to database
        conn = sqlite3.connect('heart_disease_prediction.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Get the specific prediction
        cursor.execute("""
        SELECT * FROM prediction_history
        WHERE id = ? AND user_id = ?
        """, (prediction_id, user_id))
        
        record = cursor.fetchone()
        conn.close()
        
        if not record:
            flash('Prediction not found', 'error')
            return redirect(url_for('history'))
        
        # Process the prediction data similar to the regular predict route
        user_data = {
            'age': record['age'],
            'gender': record['gender'],
            'height': record['height'],
            'weight': record['weight'],
            'ap_hi': record['ap_hi'],
            'ap_lo': record['ap_lo'],
            'cholesterol': record['cholesterol'],
            'gluc': record['gluc'],
            'smoke': record['smoke'],
            'alco': record['alco'],
            'active': record['active']
        }
        
        # Calculate BMI for risk factor analysis
        height_m = user_data["height"] / 100  # Convert cm to m
        bmi = user_data["weight"] / (height_m ** 2)
        
        # Identify influential factors for personalized recommendations
        risk_factors = []
        
        # Check for high blood pressure
        if user_data["ap_hi"] >= risk_thresholds["ap_hi"]:
            risk_factors.append({
                "factor": "Systolic Blood Pressure", 
                "value": f"{int(user_data['ap_hi'])} mmHg",
                "message": "Elevated systolic blood pressure increases heart disease risk"
            })
        
        if user_data["ap_lo"] >= risk_thresholds["ap_lo"]:
            risk_factors.append({
                "factor": "Diastolic Blood Pressure", 
                "value": f"{int(user_data['ap_lo'])} mmHg", 
                "message": "Elevated diastolic blood pressure increases heart disease risk"
            })
        
        # Check for high cholesterol
        if user_data["cholesterol"] > risk_thresholds["cholesterol"]:
            chol_status = "above normal" if user_data["cholesterol"] == 2 else "high"
            risk_factors.append({
                "factor": "Cholesterol", 
                "value": chol_status,
                "message": f"{chol_status.capitalize()} cholesterol is a major risk factor for heart disease"
            })
        
        # Check for high glucose
        if user_data["gluc"] > risk_thresholds["gluc"]:
            gluc_status = "pre-diabetic" if user_data["gluc"] == 2 else "diabetic"
            risk_factors.append({
                "factor": "Blood Glucose", 
                "value": gluc_status,
                "message": f"{gluc_status.capitalize()} glucose levels increase heart disease risk"
            })
        
        # Check for age risk
        if user_data["age"] > risk_thresholds["age"]:
            risk_factors.append({
                "factor": "Age", 
                "value": f"{int(user_data['age'])} years",
                "message": "Age over 50 increases heart disease risk"
            })
        
        # Check for physical inactivity
        if user_data["active"] == 0:
            risk_factors.append({
                "factor": "Physical Activity", 
                "value": "Inactive",
                "message": "Physical inactivity is a major risk factor for heart disease"
            })
            
        # Check for smoking
        if user_data["smoke"] == 1:
            risk_factors.append({
                "factor": "Smoking", 
                "value": "Smoker",
                "message": "Smoking significantly increases heart disease risk"
            })
        
        # Check BMI
        if bmi >= 25:
            bmi_status = "overweight" if bmi < 30 else "obese"
            risk_factors.append({
                "factor": "BMI", 
                "value": f"{bmi:.1f} ({bmi_status})",
                "message": f"BMI indicates {bmi_status}, which increases heart disease risk"
            })
        
        # Sort risk factors by importance
        sorted_risk_factors = sorted(risk_factors, key=lambda x: {
            "Cholesterol": 1,
            "Blood Glucose": 2,
            "Systolic Blood Pressure": 3,
            "Diastolic Blood Pressure": 4,
            "Smoking": 5,
            "BMI": 6,
            "Age": 7,
            "Physical Activity": 8
        }.get(x["factor"], 99))
        
        return render_template('result.html', 
                              final_prediction=record['prediction'],
                              model_predictions=[],  # No model predictions in history view
                              risk_level=record['risk_level'],
                              risk_factors=sorted_risk_factors,
                              session=session,
                              from_history=True)
    
    except Exception as e:
        import traceback
        print(traceback.format_exc())
        return render_template('error.html', message=f"An error occurred: {str(e)}")

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', message="Page not found"), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html', message="Internal server error"), 500

if __name__ == "__main__":
    app.run(debug=True)